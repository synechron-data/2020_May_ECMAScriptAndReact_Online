import React, { Component } from 'react';
import AddProductButton from './AddProductButton';
import assignAPIClient from '../../services/assign.service';
import LoaderAnimation from '../common/LoaderAnimation';
import ProductListComponent from './ProductListComponent';

class AssignmentComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { products: [], message: "Loading Products, please wait...", flag: false };
        this.deleteProduct = this.deleteProduct.bind(this);
    }

    deleteProduct(product, e) {
        assignAPIClient.deleteProduct(product).then(() => {
            this.setState({products: [...this.state.products.filter(p => p.id !== product.id)]});    
        }, (eMsg) => {
            console.log(eMsg);
        });
    }

    render() {
        return (
            <React.Fragment>
                {
                    this.state.flag === true ?
                        <React.Fragment>
                            <AddProductButton />
                            <br /><br />
                            <ProductListComponent products={this.state.products} onDelete={this.deleteProduct} />
                        </React.Fragment>
                        :
                        <div className="pt-5">
                            <LoaderAnimation />
                        </div>
                }
            </React.Fragment>
        );
    }

    componentDidMount() {
        assignAPIClient.getAllProducts().then((products) => {
            this.setState({ products: [...products], message: "", flag: true });
        }, (eMsg) => {
            this.setState({ products: [], message: eMsg, flag: true });
        });
    }
}

export default AssignmentComponent;
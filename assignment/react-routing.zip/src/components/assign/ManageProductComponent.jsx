import React, { Component } from 'react';
import ProductFormComponent from './ProductFormComponent';
import assignAPIClient from '../../services/assign.service';

class ManageProductComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { product: {}, pText: "" };
        this.updateState = this.updateState.bind(this);
        this.saveProduct = this.saveProduct.bind(this);
    }

    updateState(e) {
        const field = e.target.name;
        let product = { ...this.state.product };
        product[field] = e.target.value;
        this.setState({ product: product });
    }

    saveProduct(e) {
        e.preventDefault();

        if (this.state.product.id) {
            assignAPIClient.updateProduct(this.state.product).then((updatedProduct) => {
                this.props.history.push('/assign');
            }, (eMsg) => {
                console.log(eMsg);
            });
        } else {
            assignAPIClient.insertProduct(this.state.product).then((insertedProduct) => {
                this.props.history.push('/assign');
            }, (eMsg) => {
                console.log(eMsg);
            });
        }
    }

    render() {
        return (
            <div>
                <ProductFormComponent pageText={this.state.pText} product={this.state.product} onChange={this.updateState}
                    onSave={this.saveProduct} />
            </div>
        );
    }

    componentDidMount() {
        const productId = this.props.match.params.id;

        let product = {
            id: "",
            name: "",
            description: "",
            status: ""
        };

        if (productId) {
            assignAPIClient.getProductById(productId).then((product) => {
                var pText = "Edit Product";
                this.setState({ pText: pText, product: { ...product } });
            });
        } else {
            var pText = "Create Product";
            this.setState({ pText: pText, product: { ...product } });
        }
    }
}

export default ManageProductComponent;
import React from 'react';
import PropTypes from 'prop-types';

const Ths = ({ item }) => {
    var allHeaders = Object.keys(item).concat(["", ""]);

    var ths = allHeaders.map((item, index) => {
        return <th key={index}>{item.toUpperCase()}</th>
    });

    return (
        <tr>
            {ths}
        </tr>
    );
};

const Tds = ({ item, onEdit, onDelete }) => {
    var allValues = Object.values(item).concat([
        <a href="#" className="text-warning" onClick={(e) => {
            onEdit(e);
        }}>Edit</a>,
        <a href="#" className="text-danger" onClick={(e) => {
            onDelete(e);
        }}>Delete</a>
    ]);

    var tds = allValues.map((item, index) => {
        return <td key={index}>{item}</td>
    });

    return (
        <tr>
            {tds}
        </tr>
    );
};

const DataTable = ({ items, children, onEdit, onDelete }) => {
    if (items && items.length) {
        var item = items[0];
        var ths = <Ths item={item} />;
        var tds = items.map((item, index) => {
            return <Tds key={index} item={item} onEdit={onEdit} onDelete={onDelete} />
        });
    }

    return (
        <div className="mt-2">
            {children ? children : null}
            <table className="table table-hover">
                <thead>
                    {ths}
                </thead>
                <tbody>
                    {tds}
                </tbody>
            </table>
        </div>
    );
};

DataTable.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object).isRequired
};


export default DataTable;
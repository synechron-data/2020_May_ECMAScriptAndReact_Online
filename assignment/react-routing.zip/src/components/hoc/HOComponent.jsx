// A higher-order component is a function that takes a component and returns a new component.
import React, { Component } from 'react';

class MyComponent extends Component {
    render() {
        return (
            <div>
                <h1 className="text-info">My Component</h1>
                <h4>Added using HOC: {this.props.data}</h4>
            </div>
        );
    }
}

var obj = {
    data: "Hello from HOC"
};

var myHOC = (InputComponent) => {
    return class extends React.Component {
        componentDidMount() {
            this.setState({ data: obj.data });
        }

        render() {
            return (
                <React.Fragment>
                    <h1 className="text-success">View Extended From Higher Order Component</h1>
                    <InputComponent {...this.props} {...this.state} />
                </React.Fragment>
            );
        }
    }
}

export default myHOC(MyComponent);
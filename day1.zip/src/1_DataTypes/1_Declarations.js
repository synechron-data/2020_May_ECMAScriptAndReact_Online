// console.log("Hello from Declarations File");

// var a = 10;
// console.log(a);

// var a;
// a = 10;
// console.log(a);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.

// a = 10;
// console.log(a);
// var a;

// Definitions or Initializations are not hoisted
// console.log(a);
// var a = 10;

// Runtime sees this code
// var a;
// console.log(a);
// a = 10;

// var a = 10;
// var a = "Hello";
// console.log(a);

var a = 10;
console.log(a);

a = "Manish";
console.log(a);

a = true;
console.log(a);

a = {}
console.log(a);

// // ES 5 - Scopes

// // Global Scope
// // Function Scope (Local Scope)

// var i = "Hello";
// console.log("Before, i is", i);

// // for (var i = 0; i < 5; i++) {
// //     console.log("Inside Loop, i is", i);
// // }

// // for (var _i = 0; _i < 5; _i++) {
// //     console.log("Inside Loop, i is", _i);
// // }

// // function iterate() {
// //     for (var i = 0; i < 5; i++) {
// //         console.log("Inside Loop, i is", i);
// //     }
// // }

// // iterate();

// // IIFE
// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// })();

// console.log("After, i is", i);

// --------------------------------------------------------- ES 2015
// ES 2015 - Scopes

// Global Scope
// Function Scope (Local Scope)
// Block Scope

var i = "Hello";
// let i = "Hello";
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is", i);
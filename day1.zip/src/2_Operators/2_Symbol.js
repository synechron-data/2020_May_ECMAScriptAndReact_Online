// const Read = "Read";
// const Write = "Write";

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "READ" mode');
//     else if (mode === Write)
//         console.log('File opened in "WRITE" mode');
//     else
//         console.log('File cannot be opened');
// }

// Open(Read);
// Open(Write);

// Open("Read");
// Open("Write");

// var t = "Read";
// Open(t);

// -------------------------------------------------------
// const Read = { mode: "Read" };
// const Write = { mode: "Write" };

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "READ" mode');
//     else if (mode === Write)
//         console.log('File opened in "WRITE" mode');
//     else
//         console.log('File cannot be opened');
// }

// Open(Read);
// Open(Write);

// Open({ mode: "Read" });
// Open({ mode: "Write" });

// var t = { mode: "Read" };
// Open(t);

// -------------------------------------------------- Symbol
var Read = Symbol("Read");
var Write = Symbol("Write");

function Open(mode) {
    if (mode === Read)
        console.log('File opened in "READ" mode');
    else if (mode === Write)
        console.log('File opened in "WRITE" mode');
    else
        console.log('File cannot be opened');
}

Open(Read);
Open(Write);

Open("Read");
Open("Write");

var t = Symbol("Read");
Open(t);
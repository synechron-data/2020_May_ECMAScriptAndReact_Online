// Type Casting - Between Similar Types (Same Family of) types - int to float, float to int
// Type Conversion - Diff. Family of Types - string to int

// JavaScript Supports only Type Conversion

// var data = window.prompt("Enter a number", 0);
// console.log(data);
// console.log(typeof data);

// var d1 = data + 10;
// console.log(d1);

// var n1 = parseInt(data, 2);
// console.log(n1);

// var n1 = parseInt(data) + 10;
// console.log(n1);

// var n2 = parseFloat(data) + 10;
// console.log(n2);

// var n3 = Number(data) + 10;
// console.log(n3);

// var obj = null;
// // var obj = {};

// // if ((obj === null) || (obj === undefined)) {
// if (!obj) {
//     console.log("Is Null or Undefined...");
// } else {
//     console.log("Is Not Null or Not Undefined...");
// }

// console.log(Boolean(1));
// console.log(Boolean(0));
// console.log(Boolean(-1));
// console.log(Boolean("ABC"));
// console.log(Boolean(""));
// console.log(Boolean(null));
// console.log(Boolean(undefined));
// console.log(Boolean({}));

// console.log(true && "ABC");
// console.log(true && "ABC" || "XYZ");
// console.log(false && "ABC" || "XYZ");

// T && T = T
// T && F = F
// F && T = F
// F && F = F

// T || T = T
// T || F = T

{/* <h1 class={isSelected() && "text-info" || "text-danger"}>Some Data</h1> */}

// It is not recommended to use eval() because it is slow, it is also not secured
// console.log("5 + 5");
// console.log(eval("5 + 5"));
// console.log(eval("true && true"));
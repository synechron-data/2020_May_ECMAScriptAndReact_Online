// If I use ... on Lefthand side of EqualTo operator (Rest)
// If I use ... on Righthand side of EqualTo operator (Spread)

// ES 2015 - Array Spread - Convert Array to Comma Seperated items

// var arr1 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
// // console.log(arr1);
// // console.log(typeof arr1);

// // var arr2 = arr1;
// // var arr2 = arr1.slice();
// // var arr2 = [].concat(arr1);
// var arr2 = [...arr1];

// arr2[0] = 1000;
// console.log("Array 1", arr1);
// console.log("Array 2", arr2);

// var arr1 = [1, 2, 3, 4];
// var arr2 = [5, 6, 7, 8, 9];

// // var arr3 = [].concat(arr1, arr2);
// var arr3 = [...arr1, ...arr2];

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);
// console.log("Array 3", arr3);

// -------------------------------------------------  Array Destructuring

// var arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// // var x = arr[0];
// // var y = arr[1];

// // var [x, , y] = arr;
// // console.log(`x = ${x}, y = ${y}`);

// // Swap 2 Numbers
// // var [x, , y] = arr;
// // console.log(`Before, x = ${x}, y = ${y}`);

// // [x, y] = [y, x];

// // console.log(`After, x = ${x}, y = ${y}`);

// // Rest with Destructuring
// var [x, y, ...z] = arr;
// console.log(`x = ${x}, y = ${y}, z = ${z}`);

// var arr = [[10, 20], [30, 40], [50, 60], [70, 80, 90]];
// // var [x, y] = arr;
// // console.log(`x = ${x}, y = ${y}`);

// var [x, ...y] = arr;
// console.log(`x = ${x}, y = ${y}`);
// console.log(`x = ${typeof x}, y = ${typeof y}`);

// var arr = [{ id: 1 }, { id: 2 }, { id: 3 }];
// var [x, y] = arr;
// console.log(`x = ${JSON.stringify(x)}, y = ${JSON.stringify(y)}`);

// ----------------------------------------------------  ES 2018 (Object Rest and Spread)

// var person = { id: 1, name: "Manish", city: "Pune", state: "MH" };

// var id = person.id;
// var name = person.name;
// var address = { city: person.city, state: person.state };

// Rest with Destructuring
// var {id, name, ...address} = person;

// console.log("Id ", id);
// console.log("Name ", name);
// console.log("Address ", address);

// ----------------------------------------- Object Spread

var p1 = { id: 1, name: "Manish", address: { city: "Pune", state: "MH" } };

// var p2 = p1;

// Shallow Copy
// var p2 = Object.assign({}, p1);         // New Method of ES 2015
// var p2 = { ...p1 };                     // Object Spread

// Deep Copy
var p2 = JSON.parse(JSON.stringify(p1));

p2.name = "Abhijeet";
p2.address.city = "Mumbai";

console.log("P1 - ", p1);
console.log("P2 - ", p2);

// Third Party Library, which can be used for deep copying
// lodash
// Ramda
// rfdc (It is the fastest Deep Copy Library)
// Immutability-helper (Copy with Functions)
// Immutable.js - programatically enforce immutability

// import './1_DataTypes/1_Declarations';
// import './1_DataTypes/2_DataTypes';
// import './1_DataTypes/3_ES6_Declarations';
// import './1_DataTypes/4_Scoping';

// import './2_Operators/1_Comparision';
// import './2_Operators/2_Symbol';
// import './2_Operators/3_DataConversion';

// import './3_LoopsAndConditions/1_Loops';
// import './3_LoopsAndConditions/2_Statements';

// import './4_Functions/1_FnCreation';
// import './4_Functions/2_FnParameters';
// import './4_Functions/3_RestAndSpread';
// import './4_Functions/4_PureAndImpureFn';
import './4_Functions/5_FnOverloading';
// import './4_Functions/6_IIFE';
// function Test() {
//     console.log(this);
// }

// const Test = function () {
//     console.log(this);
// }

// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.
// const Test = () => {
//     console.log(this);
// }

// Test();
// Test.call();
// Test.apply();

// const nTest = Test.bind();
// nTest();

// var p1 = {
//     id: 1,
//     test: function () {
//         console.log(this);
//     }
// };

// p1.test();

// ------------------------------------------------------------

// function Test(x, y) {
//     console.log(this);
//     console.log(`x = ${x}, y = ${y}`);
// }

// const Test = function (x, y) {
//     console.log(this);
//     console.log(`x = ${x}, y = ${y}`);
// }

// const Test = (x, y) => {
//     console.log(this);
//     console.log(`x = ${x}, y = ${y}`);
// }

// Test(2, 3);
// var p1 = { id: 1 };
// var p2 = { id: 2 };
// Test.call(p1, 2, 3);
// Test.apply(p2, [2, 3]);

// ------------------------------------------------------------

// Constructor Function
// function Person(age) {
//     this.age = age;

//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person(20);
// // console.log(p1.age);
// // p1.growOld();
// // console.log(p1.age);
// // p1.growOld();
// // console.log(p1.age);
// // p1.growOld();
// // console.log(p1.age);
// // p1.growOld();
// // console.log(p1.age);

// setInterval(p1.growOld.bind(p1), 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// ------------------------------------------

// Lexical Closure
// function Person(age) {
//     var self = this;
//     self.age = age;

//     self.growOld = function () {
//         self.age += 1;
//     }
// }

// var p1 = new Person(20);

// setInterval(p1.growOld, 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// ------------------------------------------
// function Person(age) {
//     this.age = age;

//     this.growOld = () => {
//         this.age += 1;
//     }
// }

// var p1 = new Person(20);

// setInterval(p1.growOld, 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// ----------------------------------------

// var a = { id: 10 };

// function modify(data) {
//     // data.id = 1000;
//     data = { id: 1000 };
// }

// console.log("Before,", a);
// modify(a);
// console.log("After,", a);
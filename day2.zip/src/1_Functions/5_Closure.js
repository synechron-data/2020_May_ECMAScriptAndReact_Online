// var count = 0;

// function next() {
//     return count += 1;
// }

// console.log(next());
// count = "ABC";
// console.log(next());
// console.log(next());

// ------------------------------------------

// function next() {
//     var count = 0;

//     return count += 1;
// }

// console.log(next());
// console.log(next());
// console.log(next());

// -----------------------------------------

// const next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// console.log(next());
// console.log(next());
// console.log(next());

// -----------------------------------------

// const counter = (function () {
//     var count = 0;

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// console.log(counter.next());
// console.log(counter.next());
// console.log(counter.next());

// console.log(counter.prev());
// console.log(counter.prev());
// console.log(counter.prev());

// -----------------------------------------
function getCounter(by = 1) {
    var count = 0;
    var interval = by;

    return {
        next: function () {
            return count += interval;
        },
        prev: function () {
            return count -= interval;
        }
    };
}

var counter = getCounter();

console.log(counter.next());
console.log(counter.next());
console.log(counter.prev());
console.log(counter.prev());

console.log("\n");

var counter5 = getCounter(5);

console.log(counter5.next());
console.log(counter5.next());
console.log(counter5.prev());
console.log(counter5.prev());
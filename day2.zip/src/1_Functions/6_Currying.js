// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 76, 0, 100));
// console.log(Converter(" INR", 76, 0, 120));
// console.log(Converter(" INR", 76, 0, 190));
// console.log(Converter(" INR", 76, 0, 900));

// ---------------------------------------------------------------

// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// const mGreet = greetings("Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// const USDTOINR = Converter(" INR", 76, 0);

// console.log(USDTOINR(100));
// console.log(USDTOINR(120));
// console.log(USDTOINR(190));
// console.log(USDTOINR(900));

// -------------------------------------------------------------

function greetings(message, name) {
    console.log(`${message}, ${name}`);
}

const mGreet = greetings.bind(undefined, "Good Morning");
// console.log(mGreet);

mGreet("Abhijeet");
mGreet("Ramakant");
mGreet("Pravin");

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

const USDTOINR = Converter.bind(undefined, " INR", 76, 0);

console.log(USDTOINR(100));
console.log(USDTOINR(120));
console.log(USDTOINR(190));
console.log(USDTOINR(900));
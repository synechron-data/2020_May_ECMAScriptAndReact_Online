class Vehicle {
    constructor(m) {
        this._make = m;
    }

    start() {
        return `${this._make}, engine started`;
    }
}

class FourWheeler extends Vehicle {
    constructor(mk, md) {
        super(mk);
        this._model = md || "Civic";
    }

    // start() {
    //     var r = super.start();
    //     return `${r}, model is ${this._model}`;
    // }

    move() {
        return "I am the car";
    }
}

var v = new FourWheeler("Ford", "Mustang");
console.log(v.start());
console.log(v.move());
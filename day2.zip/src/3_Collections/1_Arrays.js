// var employees = new Array();
// var employees = new Array(2);
// var employees = new Array("abc");
// var employees = [];

// employees[0] = "ABC";
// employees[1] = "PQR";
// employees[2] = "QWE";
// employees[5] = "QQQ";

// var employees = Array.from("Manish");
// var employees = Array.from([1, 2, 3, 4, 5]);
// var employees = Array.of(10, 20, 30, 40, 50);

// var employees = [10, 20, 30, 40, 50];

// employees.push("Manish");
// employees.unshift("Abhijeet");

// console.log(employees);
// // console.log(typeof employees);
// console.log(employees.length);

// ------------------------------------------ Iterate

// var employees = [
//     { id: 1, name: "Manish" },
//     { id: 2, name: "Varun" },
//     { id: 3, name: "Paresh" },
//     { id: 4, name: "Devesh" },
//     { id: 5, name: "Atul" },
// ];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}       ${JSON.stringify(employees[i])}`);    
// }

// employees.forEach((item, index, arr) => {
//     console.log(`${index}       ${JSON.stringify(item)}`);
// });

// for (const item of employees) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const [index, item] of employees.entries()) {
//     console.log(`${index}       ${JSON.stringify(item)}`);
// }

// var r = employees.map((item) => {
//     return item.name.toUpperCase();
// });

// console.log(r);
// console.log(employees);

var numbers = [10, 20, 30, 40, 50];
console.log(numbers.reduce((accumulator, item) => accumulator + item));
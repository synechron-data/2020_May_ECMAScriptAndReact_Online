var set = new Set();
// console.log(set);
// console.log(typeof set);

// set.add(1);
// set.add(2);
// set.add(3);
// set.add(4);
// set.add(5);

// set.add(1);
// set.add(2);
// set.add(3);
// set.add(4);
// set.add(5);

var p1 = { id: 1, name: "Manish" };
var p2 = { id: 2, name: "Abhijeet" };

set.add(p1);
set.add(p2);
set.add(p1);
set.add(p2);

for (const item of set) {
    console.log(item);
}
class Queue {
    constructor() {
        this._dataArray = [];
        this._length = 0;
    }

    push(data) {
        this._dataArray.push(data);
        this._length = this._dataArray.length;
    }

    pop() {
        return this._dataArray.shift();
    }

    get length() {
        return this._length;
    }

    // [Symbol.iterator]() {
    //     let i = 0;

    //     return {
    //         next: () => {
    //             let v, d = true;

    //             if (this._dataArray[i] !== undefined) {
    //                 v = this._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             };
    //         }
    //     };
    // }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];
    //     }
    // }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }
}

let numbersQ = new Queue();
numbersQ.push(10);
numbersQ.push(20);
numbersQ.push(30);

// for (let i = 0; i < numbersQ.length; i++) {
//     console.log(numbersQ.pop());    
// }

for (const item of numbersQ) {
    console.log(item);
}
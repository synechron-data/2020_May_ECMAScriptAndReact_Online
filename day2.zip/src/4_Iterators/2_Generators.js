function* idGenerator() {
    let index = 0;
    while (true) {
        yield index++;
    }
}

let seq = idGenerator();

for (let i = 0; i < 5; i++) {
    console.log(seq.next());
}
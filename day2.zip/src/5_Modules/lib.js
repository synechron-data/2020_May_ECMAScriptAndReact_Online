// Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// // Case 2 - Multiple Export - Named Exports
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked ${x}`;
// }

// Case 3 - Default & Named Exports
export default function square(x) {
    return x * x;
}

export function check(x) {
    return `Checked ${x}`;
}